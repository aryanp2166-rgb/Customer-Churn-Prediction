"""
generate_data.py — Generates a synthetic Telco-style churn dataset.
Run this once to create data/churn_data.csv
"""

import numpy as np
import pandas as pd

np.random.seed(42)
n = 2000

def generate_churn_dataset(n_samples=2000):
    tenure = np.random.randint(1, 72, n_samples)
    monthly_charges = np.round(np.random.uniform(20, 120, n_samples), 2)
    total_charges = np.round(tenure * monthly_charges * np.random.uniform(0.9, 1.1, n_samples), 2)

    contract = np.random.choice(["Month-to-month", "One year", "Two year"],
                                 n_samples, p=[0.55, 0.25, 0.20])
    internet_service = np.random.choice(["DSL", "Fiber optic", "No"],
                                         n_samples, p=[0.34, 0.44, 0.22])
    tech_support = np.random.choice(["Yes", "No", "No internet service"],
                                     n_samples, p=[0.29, 0.49, 0.22])
    online_security = np.random.choice(["Yes", "No", "No internet service"],
                                        n_samples, p=[0.28, 0.50, 0.22])
    payment_method = np.random.choice(
        ["Electronic check", "Mailed check", "Bank transfer (automatic)", "Credit card (automatic)"],
        n_samples, p=[0.34, 0.23, 0.22, 0.21]
    )
    senior_citizen = np.random.choice([0, 1], n_samples, p=[0.84, 0.16])
    partner = np.random.choice(["Yes", "No"], n_samples, p=[0.48, 0.52])
    dependents = np.random.choice(["Yes", "No"], n_samples, p=[0.30, 0.70])
    paperless_billing = np.random.choice(["Yes", "No"], n_samples, p=[0.59, 0.41])
    phone_service = np.random.choice(["Yes", "No"], n_samples, p=[0.90, 0.10])
    multiple_lines = np.random.choice(["Yes", "No", "No phone service"],
                                       n_samples, p=[0.42, 0.48, 0.10])

    # Churn logic: higher probability for short tenure, month-to-month, high charges
    churn_prob = (
        0.05
        + 0.25 * (contract == "Month-to-month").astype(float)
        + 0.10 * (internet_service == "Fiber optic").astype(float)
        + 0.10 * (tech_support == "No").astype(float)
        + 0.10 * (senior_citizen == 1).astype(float)
        + 0.15 * (tenure < 12).astype(float)
        - 0.10 * (tenure > 36).astype(float)
        + 0.05 * (payment_method == "Electronic check").astype(float)
    )
    churn_prob = np.clip(churn_prob, 0.05, 0.90)
    churn = (np.random.rand(n_samples) < churn_prob).astype(int)

    customer_ids = [f"CUST-{str(i).zfill(5)}" for i in range(1, n_samples + 1)]

    df = pd.DataFrame({
        "customerID": customer_ids,
        "SeniorCitizen": senior_citizen,
        "Partner": partner,
        "Dependents": dependents,
        "tenure": tenure,
        "PhoneService": phone_service,
        "MultipleLines": multiple_lines,
        "InternetService": internet_service,
        "OnlineSecurity": online_security,
        "TechSupport": tech_support,
        "Contract": contract,
        "PaperlessBilling": paperless_billing,
        "PaymentMethod": payment_method,
        "MonthlyCharges": monthly_charges,
        "TotalCharges": total_charges,
        "Churn": churn
    })
    return df


if __name__ == "__main__":
    import os
    os.makedirs("data", exist_ok=True)
    df = generate_churn_dataset(n)
    df.to_csv("data/churn_data.csv", index=False)
    print(f"✅ Dataset saved to data/churn_data.csv — {len(df)} rows")
    print(f"   Churn rate: {df['Churn'].mean():.1%}")

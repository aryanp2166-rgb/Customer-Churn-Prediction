"""
src/evaluate.py — Full evaluation: metrics, confusion matrix, ROC curve, feature importance.
"""

import os, sys
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, roc_auc_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from preprocess import preprocess_pipeline

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(ROOT, "models")
REPORTS_DIR = os.path.join(ROOT, "reports")


def load_model():
    obj = joblib.load(os.path.join(MODELS_DIR, "churn_model.pkl"))
    return obj["model"], obj["name"]


def plot_confusion_matrix(y_test, y_pred):
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["No Churn", "Churn"], yticklabels=["No Churn", "Churn"], ax=ax)
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title("Confusion Matrix")
    plt.tight_layout()
    path = os.path.join(REPORTS_DIR, "confusion_matrix.png")
    plt.savefig(path, dpi=150); plt.close()
    print(f"📊 Confusion matrix → {path}")


def plot_roc_curve(model, X_test, y_test):
    y_proba = model.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    auc = roc_auc_score(y_test, y_proba)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, color="#4F46E5", lw=2, label=f"AUC = {auc:.3f}")
    ax.plot([0,1],[0,1],"--",color="gray")
    ax.set_xlabel("FPR"); ax.set_ylabel("TPR"); ax.set_title("ROC Curve")
    ax.legend(loc="lower right"); plt.tight_layout()
    path = os.path.join(REPORTS_DIR, "roc_curve.png")
    plt.savefig(path, dpi=150); plt.close()
    print(f"📈 ROC curve → {path}")
    return auc


def plot_feature_importance(model, model_name):
    feature_names = joblib.load(os.path.join(MODELS_DIR, "feature_names.pkl"))
    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
    elif hasattr(model, "coef_"):
        importances = np.abs(model.coef_[0])
    else:
        print("⚠️  Feature importances not available."); return
    indices = np.argsort(importances)[::-1][:15]
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.barplot(x=importances[indices], y=[feature_names[i] for i in indices], palette="viridis", ax=ax)
    ax.set_title(f"Top 15 Features — {model_name}"); ax.set_xlabel("Importance")
    plt.tight_layout()
    path = os.path.join(REPORTS_DIR, "feature_importance.png")
    plt.savefig(path, dpi=150); plt.close()
    print(f"🔍 Feature importance → {path}")


def main():
    os.makedirs(REPORTS_DIR, exist_ok=True)
    X_train, X_test, y_train, y_test = preprocess_pipeline()
    model, model_name = load_model()
    y_pred = model.predict(X_test)
    auc = plot_roc_curve(model, X_test, y_test)
    plot_confusion_matrix(y_test, y_pred)
    plot_feature_importance(model, model_name)
    report = classification_report(y_test, y_pred, target_names=["No Churn", "Churn"])
    with open(os.path.join(REPORTS_DIR, "classification_report.txt"), "w") as f:
        f.write(f"Model: {model_name}\nROC-AUC: {auc:.4f}\n\n{report}")
    print(f"\n✅ Evaluation complete — Model: {model_name}, ROC-AUC: {auc:.4f}")
    print(report)


if __name__ == "__main__":
    main()

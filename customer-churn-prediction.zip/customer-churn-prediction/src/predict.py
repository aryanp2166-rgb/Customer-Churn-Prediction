"""
src/predict.py — Run inference on new/unseen customers.
"""

import os, sys
import joblib
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from preprocess import clean_data, encode_features, feature_engineering

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(ROOT, "models")


def load_artifacts():
    model_obj = joblib.load(os.path.join(MODELS_DIR, "churn_model.pkl"))
    scaler = joblib.load(os.path.join(MODELS_DIR, "scaler.pkl"))
    feature_names = joblib.load(os.path.join(MODELS_DIR, "feature_names.pkl"))
    return model_obj["model"], model_obj["name"], scaler, feature_names


def preprocess_new_data(df, scaler, feature_names):
    df = clean_data(df)
    df = encode_features(df)
    df = feature_engineering(df)
    df.drop(columns=["Churn"], inplace=True, errors="ignore")
    for col in feature_names:
        if col not in df.columns:
            df[col] = 0
    return scaler.transform(df[feature_names])


def predict_churn(df: pd.DataFrame) -> pd.DataFrame:
    model, model_name, scaler, feature_names = load_artifacts()
    X = preprocess_new_data(df.copy(), scaler, feature_names)
    probabilities = model.predict_proba(X)[:, 1]
    predictions = model.predict(X)
    result = df.copy()
    if "customerID" not in result.columns:
        result.insert(0, "customerID", [f"CUST-NEW-{i+1}" for i in range(len(df))])
    result["Churn_Prediction"] = predictions
    result["Churn_Probability"] = np.round(probabilities, 4)
    result["Risk_Level"] = pd.cut(probabilities, bins=[0, 0.3, 0.6, 1.0], labels=["Low", "Medium", "High"])
    return result[["customerID", "Churn_Prediction", "Churn_Probability", "Risk_Level"]]


def sample_new_customers():
    return pd.DataFrame({
        "customerID":       ["NEW-001",         "NEW-002",    "NEW-003"],
        "SeniorCitizen":    [0,                 1,            0],
        "Partner":          ["Yes",             "No",         "Yes"],
        "Dependents":       ["No",              "No",         "Yes"],
        "tenure":           [2,                 36,           60],
        "PhoneService":     ["Yes",             "Yes",        "No"],
        "MultipleLines":    ["No",              "Yes",        "No phone service"],
        "InternetService":  ["Fiber optic",     "DSL",        "DSL"],
        "OnlineSecurity":   ["No",              "Yes",        "Yes"],
        "TechSupport":      ["No",              "No",         "Yes"],
        "Contract":         ["Month-to-month",  "One year",   "Two year"],
        "PaperlessBilling": ["Yes",             "No",         "No"],
        "PaymentMethod":    ["Electronic check","Mailed check","Bank transfer (automatic)"],
        "MonthlyCharges":   [95.50,             55.00,        40.00],
        "TotalCharges":     [191.00,            1980.00,      2400.00],
    })


if __name__ == "__main__":
    print("🔮 Running churn prediction on sample customers...\n")
    results = predict_churn(sample_new_customers())
    print(results.to_string(index=False))
    print("\n✅ Prediction complete.")

"""
src/preprocess.py — Data cleaning, encoding, and feature engineering.
"""

import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_data(path=None):
    if path is None:
        path = os.path.join(ROOT, "data", "churn_data.csv")
    df = pd.read_csv(path)
    print(f"📂 Loaded dataset: {df.shape[0]} rows, {df.shape[1]} columns")
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.drop(columns=["customerID"], inplace=True, errors="ignore")
    if df["TotalCharges"].dtype == object:
        df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    df["TotalCharges"] = df["TotalCharges"].fillna(df["TotalCharges"].median())
    if "Churn" in df.columns and df["Churn"].dtype == object:
        df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})
    print(f"✅ Data cleaned. Missing values: {df.isnull().sum().sum()}")
    return df


def encode_features(df: pd.DataFrame):
    df = df.copy()
    binary_cols = ["Partner", "Dependents", "PhoneService", "PaperlessBilling"]
    for col in binary_cols:
        if col in df.columns:
            df[col] = df[col].map({"Yes": 1, "No": 0})
    multi_cat_cols = ["MultipleLines", "InternetService", "OnlineSecurity",
                      "TechSupport", "Contract", "PaymentMethod"]
    existing_multi = [c for c in multi_cat_cols if c in df.columns]
    df = pd.get_dummies(df, columns=existing_multi, drop_first=True)
    print(f"✅ Encoding done. Shape: {df.shape}")
    return df


def feature_engineering(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["AvgMonthlySpend"] = df["TotalCharges"] / (df["tenure"] + 1)
    df["TenureGroup"] = pd.cut(df["tenure"], bins=[0, 12, 24, 48, 72],
                                labels=[0, 1, 2, 3]).astype(int)
    return df


def split_and_scale(df: pd.DataFrame, target="Churn", test_size=0.2, random_state=42):
    X = df.drop(columns=[target])
    y = df[target]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    models_dir = os.path.join(ROOT, "models")
    os.makedirs(models_dir, exist_ok=True)
    joblib.dump(scaler, os.path.join(models_dir, "scaler.pkl"))
    joblib.dump(list(X.columns), os.path.join(models_dir, "feature_names.pkl"))

    print(f"✅ Train size: {X_train_scaled.shape}, Test size: {X_test_scaled.shape}")
    print(f"   Churn rate (train): {y_train.mean():.1%} | (test): {y_test.mean():.1%}")
    return X_train_scaled, X_test_scaled, y_train, y_test


def preprocess_pipeline():
    df = load_data()
    df = clean_data(df)
    df = encode_features(df)
    df = feature_engineering(df)
    return split_and_scale(df)


if __name__ == "__main__":
    preprocess_pipeline()

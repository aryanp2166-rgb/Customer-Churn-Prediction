"""
src/train.py — Trains multiple models, picks the best, and saves it.
"""

import os
import sys
import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import roc_auc_score, classification_report

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from preprocess import preprocess_pipeline

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

MODELS = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=200, max_depth=10, random_state=42, n_jobs=-1),
    "Gradient Boosting": GradientBoostingClassifier(n_estimators=200, learning_rate=0.05, max_depth=4, random_state=42),
}


def train_and_select_best(X_train, X_test, y_train, y_test):
    best_model, best_score, best_name = None, 0, ""
    print("\n🏋️  Training models...\n")
    for name, model in MODELS.items():
        model.fit(X_train, y_train)
        roc = roc_auc_score(y_test, model.predict_proba(X_test)[:, 1])
        print(f"   {name:<25} ROC-AUC: {roc:.4f}")
        if roc > best_score:
            best_score, best_model, best_name = roc, model, name
    print(f"\n🏆 Best model: {best_name} (ROC-AUC = {best_score:.4f})")
    return best_model, best_name


def save_model(model, name):
    models_dir = os.path.join(ROOT, "models")
    os.makedirs(models_dir, exist_ok=True)
    path = os.path.join(models_dir, "churn_model.pkl")
    joblib.dump({"model": model, "name": name}, path)
    print(f"💾 Model saved → {path}")


def main():
    X_train, X_test, y_train, y_test = preprocess_pipeline()
    best_model, best_name = train_and_select_best(X_train, X_test, y_train, y_test)
    save_model(best_model, best_name)
    y_pred = best_model.predict(X_test)
    print("\n📋 Classification Report (Best Model):")
    print(classification_report(y_test, y_pred, target_names=["No Churn", "Churn"]))


if __name__ == "__main__":
    main()
